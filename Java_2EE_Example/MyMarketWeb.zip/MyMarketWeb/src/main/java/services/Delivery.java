package services;

public interface Delivery {
public double getPrice();
public String getCity();
}
