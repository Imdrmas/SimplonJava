package services;

public interface iBill {
  
}
