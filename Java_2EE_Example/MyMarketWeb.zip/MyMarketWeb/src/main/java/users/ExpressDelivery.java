package users;

import services.Delivery;

public class ExpressDelivery implements Delivery {
	private int number;

	public ExpressDelivery(int number) {
		this.number = number;
	}

	public double getPrice() {
		if(number >= 300 && number <= 301) {
			return 4.99;
		}else {
			return 6.99;
		}
		
	}
	public String getCity() {
		if(number >= 300 && number <= 301) {
			return "Paris";
		}else {
			return "Autre Ville";
		}
		
	}


}
